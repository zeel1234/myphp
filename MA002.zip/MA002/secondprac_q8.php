<?php   
  	$Flag = true;   
    print "Bool is set to $Flag\n";
    $Flag = false; 
    print "Bool is set to ";
    print (int)$Flag; 
?> 