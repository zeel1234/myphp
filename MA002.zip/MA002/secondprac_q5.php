<?php $a=100; 
if($a==100)
 {    
 	 echo "the variable equals 1!<br>"; 
 }
 if($a==true) 
 {
     echo "the variable is true!<br>";
 } 
 ?> 