<html>
<form action="authenticate.php" method="post">
<table border=1>
    <tr> 
    <td><label>Username </label></td>
    <td><input type="text" name="username"/> </td>
    </tr>
    <tr>
    <td><label> Password </label> </td>
    <td><input type="Password" name="password">
    </tr>
    <tr>
    <td><label> Name </label> </td>
    <td> <input type="text" name="Name"> </td>
    </tr>
    <tr>
    <td colspan="3" align="center"> <input type="submit"></td>
</tr>
</form>
</html>