<html>
<body>
<?php
$x=25;
$y=15;
$sum=$x+$y;
echo " Sum = $sum <br>";

$sub=$x-$y;
echo " Subtraction = $sub <br>";

$mul=$x*$y;
echo " Multiplication = $mul <br>";

$divide=$x/$y;
echo " Division= $divide <br> ";
?>
</body>
</html>