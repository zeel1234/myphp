<?php   
  $bool = false;   
  print "Bool is set to $bool\n <br>";    
  $bool = true;    
  print "Bool is set to $bool\n <br> " ;
?>