<html>
<body>
	<?php
		$x=1001;
 		var_dump($x);
 		echo "<br>";
 		$x=1001.23;
 		settype($x, "float");
 	    echo "<br>";
 		var_dump($x);
	?>


</body>
</html>