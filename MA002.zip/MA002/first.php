<html>
<body bgcolor="pink">
<h1> My first php program </h1>	
<?php 
	echo "hello world";
?>
<br>
<br>
<p>
 hello!! My name is Zeel Gandhi <br>
 I am pursuing Mca from DDIT University.
 <br>
 I have done my 
</p>
</body>
</html>