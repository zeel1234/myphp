<?php
	$num=407;
	$sum=0;
	$n=$num;
	while($n!=0)
	{
		$rem=$n;
		$sum=$sum + ($rem*$rem*$rem);
		
	}