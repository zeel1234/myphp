<html>
<body>
<?php
		$n=8;

		if($n%2==0)
			echo "$n is not prime";
		else
			echo "$n is prime";
?>
</body>
</html>