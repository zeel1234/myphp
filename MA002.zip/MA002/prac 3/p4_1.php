<?php 
 $browsers = array ("Firefox", "InternetExplorer", "Opera"); 
  echo "<select>";
  foreach($browsers as $browser)
     { 
     	  echo "<option name='$browser'>$browser</option>"; 
     } 
     echo "</select>"; ?> 