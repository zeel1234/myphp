<html>
<body>
<?php      
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ma002";

$con= new mysqli($servername, $username, $password, $dbname);

if (!$con)

  {

  die('Could not connect: ' . mysql_error());

  }

 


 

$sql = "INSERT INTO register (username, password,email,gender,city,occupation,dob,sa)
VALUES ('$_POST[username]','$_POST[passwd]','$_POST[email]','$_POST[radio]','$_POST[city]','$_POST[occupation]',$_POST[dob],$_POST[secret])";

 

if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

 
mysqli_close($con);

?>

</body>

</html>

 

 