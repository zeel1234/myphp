<html>

<body>
<?php
$x=8;
$y=9;
if($x < $y)
	echo "$y is greater than $x";
else
	echo "$x is greater than $y";
?>
</body>
</html>